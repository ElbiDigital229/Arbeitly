# Arbeitly Launchpad

Arbeitly Launchpad is an AI-powered hub for tracking job applications, managing candidates, and streamlining your hiring pipeline. It is designed to be an extension of Arbeitly.de, providing a seamless experience for recruiters and job seekers.

## Technologies

- **Vite** for fast builds and development
- **React** for building the user interface
- **TypeScript** for type safety
- **Tailwind CSS** for styling
- **shadcn/ui** for accessible and beautiful components

## Getting Started

### Prerequisites

- Node.js (v18 or higher)
- npm or bun

### Installation

1. Clone the repository:
   ```sh
   git clone <repository-url>
   ```

2. Install dependencies:
   ```sh
   npm install
   ```

3. Start the development server:
   ```sh
   npm run dev
   ```

## Development

- `npm run dev`: Start the development server
- `npm run build`: Build for production
- `npm run lint`: Run ESLint
- `npm run test`: Run tests with Vitest

## Deployment

The project can be deployed to any static site hosting provider like Vercel, Netlify, or GitHub Pages.

1. Build the project:
   ```sh
   npm run build
   ```
2. Deploy the `dist` folder to your provider of choice.

## License

All rights reserved. © Arbeitly.
